# dosbox-app
Run the old app with DOSBOX

# Greeting start
- Open file App.conf
- Change the setting for your app at the end of file. 
- Save
- Click to RUN.bat to start

# Helpful
Mount Folders
```bash
mount c D:\Labs\DOS\APPS
mount c D:\ -t cdrom
```

Commands
```bash
intro special
```

# Links
- https://archive.org/details/softwarelibrary_msdos_games?&sort=-week&page=3
